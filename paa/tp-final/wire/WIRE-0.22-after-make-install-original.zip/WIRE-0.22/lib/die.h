
#ifndef _DIE_H_INCLUDED_
#define _DIE_H_INCLUDED_

#include <config.h>

// Functions

extern void die( const char *reason );

#endif
