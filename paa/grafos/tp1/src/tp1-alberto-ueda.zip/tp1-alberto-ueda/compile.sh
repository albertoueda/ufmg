#!/bin/bash
g++ alberto-ueda-tp1.cpp -o alberto-ueda-tp1
