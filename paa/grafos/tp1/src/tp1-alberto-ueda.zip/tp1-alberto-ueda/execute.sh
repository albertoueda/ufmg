#!/bin/bash
./alberto-ueda-tp1
