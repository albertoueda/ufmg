#!/bin/bash
g++ -O3 alberto-ueda-tp3-ga.cpp -o alberto-ueda-tp3-ga
