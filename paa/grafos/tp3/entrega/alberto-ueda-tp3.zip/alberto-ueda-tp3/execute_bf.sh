#!/bin/bash
./alberto-ueda-tp3-bf $1
