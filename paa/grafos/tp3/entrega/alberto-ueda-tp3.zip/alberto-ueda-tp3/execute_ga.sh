#!/bin/bash
./alberto-ueda-tp3-ga $1
