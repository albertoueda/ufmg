#!/bin/bash
./alberto-ueda-tp3-dp $1
