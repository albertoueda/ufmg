#!/bin/bash
g++ -O3 alberto-ueda-tp3-dp.cpp -o alberto-ueda-tp3-dp
