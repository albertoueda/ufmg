#!/bin/bash
g++ -O3 alberto-ueda-tp3-bf.cpp -o alberto-ueda-tp3-bf
