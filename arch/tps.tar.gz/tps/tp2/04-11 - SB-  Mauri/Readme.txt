Resumo da situa��o
==================
Estamos realizando as tarefas do TP2 mas test�-las somente no Modelsim. O codigo est� mais limpo agora.

O que funciona
==============
	- Mem�rias duplicadas (_dados e de instru��es (sem prefixo)): arquivos RAM e MEMController
	- Soma, Load e Store no ModelSim
	- Displays num�ricos exibindo valores dos registradores

O que nao funciona
==================
	- Funcionamente geral na placa.

Misterios
=========
	- Na realidade nunca conseguimos executar na placa nem as simples somas. Uma poss�vel explica��o � que n�o conseguimos
	 executar o "reset 101" do modelsim da mesma forma da placa, o que faz as instru��es n�o serem carregadas ou executadas. -
	Por�m, foram feitos testes exaustivos e o sinais de clock e reset est�o sendo transmitidos corretamente na placa-
	
Grupo:
Alberto Ueda
Ana Luiza
Junio
Mauri Miguel
Julio Nardael
-Ana Luiza F