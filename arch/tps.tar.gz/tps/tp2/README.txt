Resumo da situação
==================
Podemos começar as tarefas do TP2 mas testá-las somente no Modelsim. O codigo também está mais limpo agora.

O que funciona
==============
	- Memórias duplicadas (_dados e de instruções (sem prefixo)): arquivos RAM e MEMController
	- Soma, Load e Store no ModelSim
	- Displays numéricos exibindo valores dos registradores

O que nao funciona
==================
	- (Placa) Load e Store
	- (Placa) Os displays não estão exibindo os valores dos registradores utilizados em Ram.v, mostrando apenas aqueles alterados em Registers.v. 
			Provavelmente pois eles não estão sendo alterados na placa.

Misterios
=========
	- Na realidade nunca conseguimos executar na placa nem as simples somas. Uma possível explicação é que não conseguimos executar o "reset 101" do modelsim da mesma forma da placa, o que faz as instruções não serem carregadas ou executadas.


Proxima tarefa planejada
========================
	- (Alberto) Começar a implementar M0 da unidade funcional de memória do i4.